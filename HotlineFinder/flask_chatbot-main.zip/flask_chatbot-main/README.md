# flask_chatbot
This is a simple chatbot created using Flask (Python framework).
This chatbot uses a simple algorithm that to understand the message does:
1. Delete all dots, commas, dashes and stuff like that.
2. Convert the user's message to lowercase to understand it better.
3. Work out a response based on how likely that message is to mean one of its possible responses by comparing them.
# Version 1.0
